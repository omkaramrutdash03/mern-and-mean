import AllRoutes from  "./AllRoutes";
import HomePage from "./components/homepage";
import Navbar from "./components/navbar";

function App(){
  return <AllRoutes/>;
}
export default App;
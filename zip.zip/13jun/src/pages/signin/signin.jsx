import React from "react";
function Signin(){
    return(
    <div>
        <input type="text" placeholder="Enter Email" />
        <input  type ="text" placeholder="Enter Pass"/>
        <button>Sign in</button>
    </div>
    );
}
export default Signin;
import React from "react";
function Signup(){
    return(
        <div>
            <input type="text"placeholder="Enter Email" />
            <input type="text"placeholder="Enter Pass" />
            <input type="text"placeholder="Enter Email" />
            <input type="text"placeholder="Enter Pass" />
            <button>Sign up</button>
        </div>
    );
}
export default Signup;